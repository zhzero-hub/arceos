#include <stdio.h>

int main()
{
    printf("Hello, %c app!\n", 'C');
    return 0;
}
