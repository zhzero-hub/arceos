#ifndef _SYS_PARAM_H
#define _SYS_PARAM_H

#define MAXPATHLEN 4096

#endif // _SYS_PARAM_H
