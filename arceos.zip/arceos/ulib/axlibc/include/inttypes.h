#ifndef _INTTYPES_H
#define _INTTYPES_H

#include <stddef.h>

#define __PRI64 "l"

#define PRIu64 __PRI64 "u"

#endif
