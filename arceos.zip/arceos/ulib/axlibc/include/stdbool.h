#ifndef __STDBOOL_H__
#define __STDBOOL_H__

/* Represents true-or-false values */
#ifndef __cplusplus
#define true 1
#define false 0
#define bool _Bool
#endif

#endif // __STDBOOL_H__
