#ifndef _TERMIOS_H
#define _TERMIOS_H

struct winsize {
    unsigned short ws_row, ws_col, ws_xpixel, ws_ypixel;
};

#endif // _TERMIOS_H
