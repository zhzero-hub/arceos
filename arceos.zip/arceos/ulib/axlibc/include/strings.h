#ifndef __STRINGS_H__
#define __STRINGS_H__

#endif // __STRINGS_H__
