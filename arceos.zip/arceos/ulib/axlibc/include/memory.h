#ifndef __MEMORY_H__
#define __MEMORY_H__

#include <string.h>

#endif // __MEMORY_H__
