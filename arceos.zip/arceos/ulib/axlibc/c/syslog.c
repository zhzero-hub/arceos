#include <stdio.h>
#include <syslog.h>

// TODO
void syslog(int __pri, const char *__fmt, ...)
{
    unimplemented();
    return;
}

// TODO
void openlog(const char *__ident, int __option, int __facility)
{
    unimplemented();
    return;
}
