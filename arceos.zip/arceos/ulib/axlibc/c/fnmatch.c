#include <fnmatch.h>
#include <stdio.h>

#define END         0
#define UNMATCHABLE -2
#define BRACKET     -3
#define QUESTION    -4
#define STAR        -5

// TODO
int fnmatch(const char *pat, const char *str, int flags)
{
    unimplemented();
    return 0;
}
