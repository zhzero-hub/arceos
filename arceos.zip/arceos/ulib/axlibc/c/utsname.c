#include <stdio.h>
#include <sys/utsname.h>

// TODO
int uname(struct utsname *a)
{
    unimplemented();
    return 0;
}
