#include <stdio.h>
#include <sys/resource.h>
#include <sys/wait.h>

// TODO
pid_t waitpid(pid_t pid, int *status, int options)
{
    unimplemented();
    return 0;
}

// TODO
pid_t wait3(int *status, int _options, struct rusage *usage)
{
    unimplemented();
    return 0;
}
