#include <dlfcn.h>
#include <pthread.h>
#include <stdio.h>

// TODO
int dladdr(const void *__address, Dl_info *__info)
{
    unimplemented();
    return 0;
}

// TODO
void *dlopen(const char *__file, int __mode)
{
    unimplemented();
    return NULL;
}

// TODO
char *dlerror()
{
    unimplemented();
    return NULL;
}

// TODO
void *dlsym(void *__restrict__ __handle, const char *__restrict__ __name)
{

    unimplemented();
    return NULL;
}

// TODO
int dlclose(void *p)
{
    unimplemented();
    return 0;
}
