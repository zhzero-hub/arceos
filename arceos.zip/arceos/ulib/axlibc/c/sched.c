#include <sched.h>
#include <stdio.h>

// TODO
int sched_setaffinity(pid_t __pid, size_t __cpusetsize, const cpu_set_t *__cpuset)
{
    unimplemented();
    return 0;
}
